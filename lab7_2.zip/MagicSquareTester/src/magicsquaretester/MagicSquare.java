/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package magicsquaretester;

/**
 *
 * @author Tatiyakorn
 * 
 */
public class MagicSquare {
 public int Square[][] ;
    private int n ;
    public void MakeSquare(int num){
        n = num;
        Square = new int[n][n];
        for(int i = 0; i < n;i++)
            for(int j =0 ; j< n; j++)
                Square[i][j] =0;
    }
    public void FillSquare(){
        int n2 = n*n;
        int i = (n-(n/2)-1),j = n-1;
        for(int k = 1; k <=n2;k++){
            if(k==1){
                Square[i][j]=1;
                i++;
                j++;
            } 
            else if(i<n&&j<n&&Square[i][j]==0){
                Square[i][j] = k;
                i++;
                j++;
            }else if(j<n&&i==n&&Square[0][j]==0){
                Square[0][j]= k ;
                i=1;
                j++;
            }else if(i<n&&j==n&&Square[i][0]==0){
                Square[i][0] = k;  
                 i++;
                j=1;
            }else if(i<n&&j<n&&Square[i][j]!=0){
                Square[i-1][j-2] = k; 
                 j--;
            }
            else if(i==n&&j==n&&Square[n-1][n-1]!=0){
                Square[i-1][j-2] = k; 
                j-=1;
                i=0;
             }           
        }
    }
    public String toString(){
        String r ="";
        for(int j = 0; j < n;j++){
            for(int i = 0; i< n ; i++){
                r = r+Square[i][j]+" ";
            }
           r = r+"\n"; 
        } 
        return r;
    }
}   