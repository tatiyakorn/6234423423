package lab11_1;
import java.util.ArrayList;

public class SelfCheckOut implements SimpleQueue  {
    ArrayList<Object> Store = new ArrayList<>();
    ArrayList<Double> amount = new ArrayList<>();
    int count;
    double total;

    @Override
    public void enqueue(Object o) {
        Product i = (Product) o;
        Store.add(i.getGoods());
        amount.add(i.getAmount());
        System.out.println(Store.get(count)+" is added in queue");
        count++;
    }
    @Override
    public void dequeue() {
        Store.remove(0);
        total(amount.get(0));
        amount.remove(0);
        
    }
    public void total(double i){
        total+=i;
    }
    
     public double getAmount(){
       return total;
    }    
}
