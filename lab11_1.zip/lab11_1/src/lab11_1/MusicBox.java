package lab11_1;
import java.util.ArrayList;
public class MusicBox implements SimpleQueue  {
    ArrayList<Object> Listsong = new ArrayList<>();

    @Override
    public void enqueue(Object o) {
        Listsong.add(o);
        System.out.println(Listsong.get(0)+" is added in queue");
        
    }
    @Override
    public void dequeue() {
        System.out.println("Now playing "+Listsong.get(0));
        Listsong.remove(0);
    }   
}