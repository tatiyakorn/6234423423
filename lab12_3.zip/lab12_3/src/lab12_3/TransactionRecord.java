package lab12_3;

public class TransactionRecord {
    private int acctNo;
    private double amount ;
    public TransactionRecord(int acctNo,double amount){
        this.amount = amount;
        this.acctNo = acctNo;
    }
    public void setAcctNo(int acctNo){
        this.acctNo = acctNo;
    }
    public int getAcctNo(){
        return acctNo;
    }
    public void setAmount(double amount){
        this.amount = amount;
    }
    public double getAmount(){
        return amount;
    }
}
