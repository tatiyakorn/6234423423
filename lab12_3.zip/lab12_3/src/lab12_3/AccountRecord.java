package lab12_3;

public class AccountRecord {
    private int acctNo;
    private String name;
    private double balance; 
    private int transCnt =0;//นบัว่าบญัชีนที้ารายการtransactionไปกี่ครัง้    
   
    public AccountRecord (int acctNo, String name, double balance) { 
        this.acctNo = acctNo;
        this.name = name;
        this.balance = balance;
    }
    public void combine(TransactionRecord t){
        balance+=t.getAmount();
        transCnt ++;
    }
    public int getAcctNo()    {return acctNo; }
    public String getName()   {return name; }
    public double getBalance(){return balance; }
    public int getTransCnt()  {return transCnt; }
}

