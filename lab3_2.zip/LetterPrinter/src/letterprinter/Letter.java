/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package letterprinter;

/**
 *
 * @author Tatiyakorn
 */
public class Letter {
    private String from;
    private String to;
    private String line="";
    //private double text;
    public Letter(String from, String to){
       this.from = from;
       this.to = to;       
    }
    public void addLine(String line) {
        this.line = this.line+"\n"+line;
    }
    public String getText() {
        String text = "Dear "+from+":"+"\n"+this.line+"\n\n"+"Sincerely,"+"\n\n"+to+"\n\n";
        return text;
    }   

    
}
