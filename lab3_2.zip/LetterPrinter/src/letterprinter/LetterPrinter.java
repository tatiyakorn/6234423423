/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package letterprinter;

/**
 *
 * @author Tatiyakorn
 */
public class LetterPrinter {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Letter jade = new Letter("Jade","Clarissa");
        jade.addLine("we must find Simon quickly.\nHe might be in danger");
        System.out.printf(jade.getText());
    }
    
}
