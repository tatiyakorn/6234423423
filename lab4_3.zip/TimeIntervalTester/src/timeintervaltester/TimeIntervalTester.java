/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package timeintervaltester;
import java.util.Scanner;
import java.lang.Math;



/**
 *
 * @author Tatiyakorn
 */
public class TimeIntervalTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);
        System.out.print("Enter start time : ");
        double Start = num.nextDouble();
        System.out.print("Enter end time : ");
        double End = num.nextDouble();
        TimeInterval TIME = new TimeInterval();
        TIME.Time(Start,End);
        
        System.out.println((int)TIME.getHours()+" hours "+ Math.abs((int)TIME.getMinutes())+" minutes");
    }   
}

    
    

