package lab9_2;
public class sine extends Taylor  {
    public sine(int k,double x){
        super(k,x);
    }
    @Override
    public double getApprox() {
        double result = 0 ; 
        for(int n = 0; n<=super.getlter();n++){
           double x = super.getValue();
           double y = 0;
           double z = 1;
           for(int i = 1 ; i<= n;i++ ){
               z*=(-1); }
           if((2*n)+1 == 0){ x =1;}
           else if((2*n)+1 == 1){ x = super.getValue();}
           else{
                for(int i = 1;i<(2*n)+1 ;i++){
                    x*=x;}     
           }
           y = (z*x)/super.factortial((2*n)+1);
           result+=y;
       }
        return result;
    }
    @Override
    public void printValue() {
        System.out.println("Value from Math.sine() is "+Math.sin(super.getValue()));
        System.out.println("Approximated value is "+getApprox());
    }
}