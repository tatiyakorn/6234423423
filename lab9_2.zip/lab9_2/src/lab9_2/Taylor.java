package lab9_2;
public abstract class Taylor {
    private int k;
    private double x;
    public Taylor(int k,double x){
        setlter(k);
        setValue(x);
    }
    public int factortial(int n){
        int result = 1;
        for(int i = 1 ;i<=n;i++){
            result*=i;
        }
        return result;
    }
    public void setlter(int k){
        this.k = k;
    }
    public int getlter(){
        return k;    
    }
    public void setValue(double x){
        this.x =x;
    }
    public double getValue(){
        return x;
    }
    public abstract void printValue();
    public abstract double getApprox();
}