/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package insectpopulationtester;

/**
 *
 * @author Tatiyakorn
 */
public class InsectPopulation {
    public double insects;
    public InsectPopulation(int num){
        insects = num ;
    }
    
    public void breed(){
        insects = insects*2;
    }
    
    public void spray(){
        insects =insects-(insects*0.1);
    }
    
    public double getNumInsect(){
        return insects;
    }
}
