package lab8_2;
public class Question {
    private String text;
    private String answer;
    public Question(String text){
        this.text = text;
    }
    public String getText(){
        return text;
    }
    public void setText(String Text){
        text = Text;
    }
    public String getAnswer(){
        return answer;
    }
    public void setAnswer(String Ans){
        answer = Ans;
    }
    public Boolean checkAnswer(String response){
        if(!response.equals(answer)){
            return false;
        }
        return true;
    }
    public void display(){
        System.out.println(text);
    }
}
