package lab8_2;
public class NumericQuestion extends Question{
    public NumericQuestion(String Text){
        super(Text);
    }
    @Override
    public Boolean checkAnswer(String response){
        double res = Double.parseDouble(response);
        double ans = Double.parseDouble(getAnswer());
        if(ans-res<0.01&&res-ans<0.01){
            return true;
        }
        return false;
    }
}
