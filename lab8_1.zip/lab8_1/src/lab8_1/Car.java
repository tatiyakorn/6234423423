package lab8_1;
public class Car 
{
    private int gas; 
    private int efficiency; 
    public Car(int gas, int efficiency)
    {
        this.gas = gas;
        this.efficiency = efficiency;
    }
    
    
    public void drive(double distance)
    {
        if (gas>(distance/efficiency))
        {
            gas -= distance/efficiency;
        }
        else 
        {
            System.out.println("You cannot drive too far, please add gas");
        }
    }
    
    
    public void setGas(double amount)
    {
        gas = (int) amount;
    }
    
    
    public double getGas()
    {
        return gas;
    }
    
    
    public int getEfficiency()
    {
        return efficiency;
    }
    
    
    public void addGas(int amount)
    {
        gas += amount;
    }
}
