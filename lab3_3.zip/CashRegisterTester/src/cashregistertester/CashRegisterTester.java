/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cashregistertester;

/**
 *
 * @author Tatiyakorn
 */
public class CashRegisterTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       CashRegister test = new CashRegister();
        test.getTax(7);
        test.recordPurchase(50);
        test.recordPurchase(10);
        test.recordTaxPurchase(20);
        test.setPayment(100);
        test.getTotalTax();
        test.giveChange();

    }
    
}
