/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cashregistertester;

/**
 *
 * @author Tatiyakorn
 */
public class CashRegister {
    private double payment;
    private double value;
    private double valueTax;
    private double change;
    private double tax;

    public void recordPurchase(double amount) {
        value += amount;

    }
    public void getTax(double Tax) {
        tax = Tax/100;

    }
    public void recordTaxPurchase(double amountTax) {
        valueTax += amountTax;

    }
    public void setPayment(double paid) {
        payment += paid;

    }

    public void getTotalTax() {
        tax = valueTax * tax;
    }
    public void giveChange() {
        change = 0;
        change = payment - (value + (valueTax + tax));
        System.out.println("Your change is "+(float)change);
        value = 0;
        valueTax = 0;
        payment = 0;
        tax = 0;

    }


}


    

