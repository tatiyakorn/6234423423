package lab10_2;
import java.util.ArrayList;
public class BusTester {
    public static void main(String[] args) {
        ArrayList<Object> arr = new ArrayList<Object>();
        Hybrid n1 = new Hybrid(45,1200000,600,150,1);
        n1.getEmission();
        arr.add(n1);
        CNGBus n2 = new CNGBus(50,1000000,200,2);
        arr.add(n2);
        for(int i =0 ; i<arr.size();i++){
            if(arr.get(i)instanceof CNGBus){
                CNGBus c1 = (CNGBus)arr.get(i);
                System.out.println("ID: "+(i+1)+"\nEmission Tier: "+(c1.getEmission())+"\nAccel: "+(c1.getAccel()));
            }
            else{
                 Hybrid c2 = (Hybrid)arr.get(i); 
                 System.out.println("ID: "+(i+1)+"\nEmission Tier: "+c2.getEmission()+"\nAccel: "+c2.getAccel());  
                }
        }         
    }    
}
