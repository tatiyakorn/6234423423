package lab10_2;
public interface Electric {
    double LOW_VOLTAGE = 480;
    double HIGH_VOLTAGE = 600;
    double getVoltage();
}
