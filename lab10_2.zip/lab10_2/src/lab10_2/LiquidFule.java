package lab10_2;
public interface LiquidFule {
    double getRange();
    int getEmission();
}
