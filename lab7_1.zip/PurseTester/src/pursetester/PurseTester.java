/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pursetester;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Tatiyakorn
 */
public class PurseTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     Purse walletA = new Purse();
        Purse walletB = new Purse();
        ArrayList<String> coinA = new ArrayList<String>();
        ArrayList<String> coinB = new ArrayList<String>();
        String getCoin ;
        String getCoin2;
        Scanner keyboard = new Scanner(System.in);
        System.out.print("Enter coin in wallet 1(Penny,Nickel,Dime,Half,Quarter): ");
                getCoin = keyboard.nextLine();
        if(!"Enough".equals(getCoin)){
            
              do{
                if(!"Quarter".equals(getCoin) &&  !"Dime".equals(getCoin) && !"Nickel".equals(getCoin) && !"Half".equals(getCoin) && !"Penny".equals(getCoin)&& !"Enough".equals(getCoin)  ){
                    System.out.print("Enter coin in wallet 1(Penny,Nickel,Dime,Half,Quarter): ");
                    getCoin = keyboard.nextLine();
           
                }else if (getCoin!="Enough"){
                    walletA.addCoin(getCoin);
                    System.out.print("Enter coin in wallet 1(Penny,Nickel,Dime,Half,Quarter): ");
                    getCoin = keyboard.nextLine();
                    
                }
                
            }while(!"Enough".equals(getCoin) );
            System.out.print("Wallet 1: ");
            walletA.toString(); 
            coinA = walletA.reverse();
        }
                System.out.print("Enter coin in wallet 2(Penny,Nickel,Dime,Half,Quarter): ");
                getCoin2 = keyboard.nextLine();
        if(!"Enough".equals(getCoin2)){
            
              do{
                if(!"Quarter".equals(getCoin2) &&  !"Dime".equals(getCoin2) && !"Nickel".equals(getCoin2) && !"Half".equals(getCoin2) && !"Penny".equals(getCoin2)&& !"Enough".equals(getCoin2)  ){
                    System.out.print("Enter coin in wallet 2(Penny,Nickel,Dime,Half,Quarter): ");
                    getCoin2 = keyboard.nextLine();
           
                }else if (getCoin2!="Enough"){
                    walletB.addCoin(getCoin2);
                    System.out.print("Enter coin in wallet 2(Penny,Nickel,Dime,Half,Quarter): ");
                    getCoin2 = keyboard.nextLine();
                    
                }
                
            }while(!"Enough".equals(getCoin2) );
            System.out.print("Wallet 2: ");
            walletB.toString();  
            coinB = walletB.reverse();
        }
        
        ArrayList<String> coinA2 = (ArrayList<String>)coinA.clone();
        ArrayList<String> coinB2 = (ArrayList<String>)coinB.clone();
        walletB.transfer(coinB,coinA);
        System.out.println("Same contens: "+walletA.SameContens(coinB2,coinA2));
        System.out.println("Same coins: "+walletA.samecoins(coinB2,coinA2));
    }
    
}

   
