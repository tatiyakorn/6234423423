package lab9_1;
class Arraylist<T> {    
}
