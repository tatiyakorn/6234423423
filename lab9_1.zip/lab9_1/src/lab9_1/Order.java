package lab9_1;
import java.util.ArrayList;
public class Order {
    public static int cntOrder = 0;
    private int id;
    private Customer c;
    private ArrayList<Pizza> p;
    public Order(Customer customer){
        this.p = new ArrayList<Pizza>();
        c = customer;
        for (int i =0 ;i<= cntOrder;i++){
            id++;       }
    }
    public void addPizza(Pizza piz){
         p.add(piz);
    }
    public String getOrderDetail(){
        cntOrder++;
        double price = 0;
        String order =""+p.get(0);
        for(int i = 0;i<p.size();i++){
            price += (p.get(i)).getPrice()-(((c.getDiscount()/100))*(p.get(i)).getPrice());
        }
        for(int i = 1;i<p.size();i++){
           order+=("\n"+p.get(i));
        }
        return "Order id : "+id+"\n"+c.toString()+"\n"+order+"\nTotal prices : "+p.size()+"\nTotal cost : "+price;
    }
    public double calculatePayment(){
        double price = 0;
        for(int i = 0;i<p.size();i++){
            price += (p.get(i)).getPrice()-(((c.getDiscount()/100))*(p.get(i)).getPrice());        }
        return price;
    }
}

