package lab9_1;
public class PizzaSpecial extends Pizza{
    private String special;
    public PizzaSpecial(String name,double price,String extra){
        super(name,price);
        special = extra;
    }
    public String getSpecial(){
        return special;
    }
    @Override
     public String toString(){
        return super.getName()+" price : "+super.getPrice()+"special : "+special;
    }
  }
